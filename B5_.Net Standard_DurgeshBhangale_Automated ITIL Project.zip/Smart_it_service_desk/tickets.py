import datetime
import uuid


class Ticket:
    PRIORITY_RULES = {
        "server down": "P1",
        "internet down": "P2",
        "laptop slow": "P3",
        "password reset": "P4",
    }
    SLA_HOURS = {"P1": 1, "P2": 4, "P3": 8, "P4": 24}
    VALID_STATUS = {"Open", "In Progress", "Closed", "Escalated", "SLA Breached"}

    def __init__(
        self,
        employee,
        dept,
        issue,
        category,
        status="Open",
        created=None,
        ticket_id=None,
        priority=None,
        ticket_type="General",
        closed=None,
    ):
        self.id = ticket_id or self.generate_id()
        self.employee = employee.strip()
        self.dept = dept.strip()
        self.issue = issue.strip()
        self.category = category.strip()
        self.ticket_type = ticket_type
        self.priority = priority or self.assign_priority(issue)
        self.created = created or datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        self.closed = closed
        self._status = "Open"
        self.status = status

    @property
    def status(self):
        return self._status

    @status.setter
    def status(self, value):
        if value not in self.VALID_STATUS:
            raise ValueError(f"Invalid status: {value}")
        self._status = value

    @staticmethod
    def generate_id():
        return str(uuid.uuid4())[:8]

    @classmethod
    def assign_priority(cls, issue):
        normalized = issue.strip().lower()
        return cls.PRIORITY_RULES.get(normalized, "P4")

    @classmethod
    def sla_for_priority(cls, priority):
        return cls.SLA_HOURS.get(priority, 24)

    def close(self):
        self.status = "Closed"
        self.closed = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    def to_dict(self):
        return {
            "id": self.id,
            "employee": self.employee,
            "dept": self.dept,
            "issue": self.issue,
            "category": self.category,
            "priority": self.priority,
            "status": self.status,
            "created": self.created,
            "closed": self.closed,
            "ticket_type": self.ticket_type,
        }

    @classmethod
    def from_dict(cls, record):
        ticket_type = record.get("ticket_type", "General")
        if ticket_type == "Incident":
            ticket_cls = IncidentTicket
        elif ticket_type == "ServiceRequest":
            ticket_cls = ServiceRequest
        else:
            ticket_cls = cls
        return ticket_cls(
            employee=record.get("employee", "Unknown"),
            dept=record.get("dept", "Unknown"),
            issue=record.get("issue", "Unknown"),
            category=record.get("category", "General"),
            status=record.get("status", "Open"),
            created=record.get("created"),
            ticket_id=record.get("id"),
            priority=record.get("priority"),
            closed=record.get("closed"),
        )

    def __iter__(self):
        for key, value in self.to_dict().items():
            yield key, value

    def __repr__(self):
        return f"Ticket(id={self.id}, issue={self.issue}, priority={self.priority}, status={self.status})"

    def __str__(self):
        return f"[{self.id}] {self.issue} ({self.priority}) - {self.status}"


class IncidentTicket(Ticket):
    def __init__(self, *args, **kwargs):
        kwargs["ticket_type"] = "Incident"
        super().__init__(*args, **kwargs)


class ServiceRequest(Ticket):
    def __init__(self, *args, **kwargs):
        kwargs["ticket_type"] = "ServiceRequest"
        super().__init__(*args, **kwargs)


class ProblemRecord(Ticket):
    def __init__(self, *args, occurrences=0, root_cause="Pending", **kwargs):
        kwargs["ticket_type"] = "Problem"
        super().__init__(*args, **kwargs)
        self.occurrences = occurrences
        self.root_cause = root_cause

    def to_dict(self):
        data = super().to_dict()
        data.update({"occurrences": self.occurrences, "root_cause": self.root_cause})
        return data
