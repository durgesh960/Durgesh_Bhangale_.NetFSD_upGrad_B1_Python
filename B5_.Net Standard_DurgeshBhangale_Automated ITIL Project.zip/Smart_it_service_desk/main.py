from itil import DuplicateRecordError, EmptyValueError, ITILManager, InvalidTicketIDError
from monitor import monitor_system
from reports import daily_summary, monthly_trend
from utils import load_tickets, log_event, save_tickets

def menu():
    itil_manager = ITILManager()
    while True:
        print("\nSmart IT Service Desk")
        print("1. Create Ticket")
        print("2. View All Tickets")
        print("3. Search Ticket by ID")
        print("4. Update Ticket Status")
        print("5. Close Ticket")
        print("6. Delete Ticket")
        print("7. Monitor System")
        print("8. Daily Report")
        print("9. Monthly Report")
        print("10. Track Change Request")
        print("11. Exit")

        choice = input("Choose option: ")
        tickets = load_tickets()

        try:
            if choice == "1":
                emp = input("Employee: ")
                dept = input("Dept: ")
                issue = input("Issue: ")
                cat = input("Category (Incident/Service/Monitoring): ")
                created = itil_manager.create_ticket(tickets, emp, dept, issue, cat)
                itil_manager.create_problem_records(tickets)
                save_tickets(tickets)
                log_event("Ticket created", "info")
                print("Ticket Created:", created)
            elif choice == "2":
                sorted_tickets = itil_manager.sort_tickets(tickets, key="created")
                for ticket in sorted_tickets:
                    print(ticket)
            elif choice == "3":
                tid = input("Enter ID: ").strip()
                ticket = itil_manager.search_ticket_by_id(tickets, tid)
                print(ticket)
            elif choice == "4":
                tid = input("Enter ID: ").strip()
                status = input("New Status (Open/In Progress/Escalated/Closed): ").strip()
                updated = itil_manager.update_ticket_status(tickets, tid, status)
                save_tickets(tickets)
                log_event("Ticket updated", "info")
                print("Updated:", updated)
            elif choice == "5":
                tid = input("Enter ID: ").strip()
                closed = itil_manager.close_ticket(tickets, tid)
                save_tickets(tickets)
                log_event("Ticket closed", "info")
                print("Closed:", closed)
            elif choice == "6":
                tid = input("Enter ID: ").strip()
                updated_tickets = itil_manager.delete_ticket(tickets, tid)
                save_tickets(updated_tickets)
                tickets = updated_tickets
                log_event("Ticket deleted", "warning")
                print("Deleted successfully")
            elif choice == "7":
                monitor_system()
            elif choice == "8":
                daily_summary()
            elif choice == "9":
                monthly_trend()
            elif choice == "10":
                title = input("Change Title: ")
                requested_by = input("Requested By: ")
                change = itil_manager.track_change(title, requested_by)
                print("Change Request Tracked:", change)
            elif choice == "11":
                break
            else:
                print("Invalid input")

            breached = itil_manager.breached_sla_tickets(tickets)
            escalated = itil_manager.escalate_unresolved(tickets)
            if breached or escalated:
                save_tickets(tickets)
            if breached:
                print(f"SLA breached tickets: {len(breached)}")
            if escalated:
                print(f"Escalated tickets: {len(escalated)}")

        except (InvalidTicketIDError, EmptyValueError, DuplicateRecordError, ValueError) as exc:
            log_event(f"Error: {exc}", "error")
            print("Error:", exc)
        except FileNotFoundError as exc:
            log_event(f"File error: {exc}", "critical")
            print("File error:", exc)
        except Exception as exc:
            log_event(f"Unexpected error: {exc}", "critical")
            print("Unexpected error:", exc)


if __name__ == "__main__":
    menu()
