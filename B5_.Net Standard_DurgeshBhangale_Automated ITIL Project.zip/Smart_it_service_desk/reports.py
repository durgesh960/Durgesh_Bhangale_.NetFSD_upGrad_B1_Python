import datetime
import json
import os
from collections import Counter

from itil import ITILManager
from utils import load_tickets


class ReportGenerator:
    def __init__(self):
        self.itil_manager = ITILManager()

    def _today_tickets(self, tickets):
        today = datetime.datetime.now().strftime("%Y-%m-%d")
        return [row for row in tickets if row.get("created", "").startswith(today)]

    def daily_summary(self):
        tickets = load_tickets()
        today_tickets = self._today_tickets(tickets)
        report = {
            "total_tickets": len(today_tickets),
            "open_tickets": sum(1 for row in today_tickets if row.get("status") in {"Open", "In Progress", "Escalated"}),
            "closed_tickets": sum(1 for row in today_tickets if row.get("status") == "Closed"),
            "high_priority_tickets": sum(1 for row in today_tickets if row.get("priority") == "P1"),
            "sla_breaches": sum(1 for row in today_tickets if row.get("status") == "SLA Breached"),
        }
        print("Daily Summary Report")
        for key, value in report.items():
            print(f"{key}: {value}")
        return report

    def monthly_trend(self):
        tickets = load_tickets()
        issues = [row.get("issue", "Unknown") for row in tickets]
        departments = [row.get("dept", "Unknown") for row in tickets]

        repeated_problems = []
        problem_path = "data/problems.json"
        if os.path.exists(problem_path):
            with open(problem_path, "r", encoding="utf-8") as handle:
                try:
                    repeated_problems = json.load(handle)
                except json.JSONDecodeError:
                    repeated_problems = []

        issue_counts = Counter(issues)
        report = {
            "most_common_issue": issue_counts.most_common(1),
            "avg_resolution_time_hours": self.itil_manager.average_resolution_hours(tickets),
            "department_with_most_incidents": Counter(departments).most_common(1),
            "repeated_problems": len(repeated_problems),
        }

        print("Monthly Trend Report")
        for key, value in report.items():
            print(f"{key}: {value}")
        return report


def daily_summary():
    return ReportGenerator().daily_summary()


def monthly_trend():
    return ReportGenerator().monthly_trend()
