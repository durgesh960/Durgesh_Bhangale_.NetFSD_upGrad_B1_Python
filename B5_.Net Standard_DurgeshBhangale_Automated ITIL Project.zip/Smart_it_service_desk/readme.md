# Smart IT Service Desk Automation

## Modules
- Ticket Management: create, view, search, update, close, delete.
- ITIL Workflows: incident management, service request management, problem management, change tracking, SLA monitoring.
- System Monitoring: CPU, memory, disk free percentage, network throughput.
- Logging: INFO, WARNING, ERROR, CRITICAL in data/logs.txt.
- Reports: daily summary and monthly trend.
- Backup: automatic backup to data/backup.csv after ticket changes.

## Project Structure
- main.py
- tickets.py
- monitor.py
- reports.py
- itil.py
- utils.py
- logger.py
- requirements.txt
- data/tickets.json
- data/problems.json
- data/logs.txt
- data/backup.csv

## Setup And Run
```bash
pip install -r requirements.txt
python main.py
```

## Debugging In VS Code
- Set breakpoints in main.py and itil.py.
- Use Watch panel for variables: tickets, breached, escalated.
- Use Call Stack to inspect menu flow and ITIL service calls.
- Use Step Over/Into during create_ticket and breached_sla_tickets execution.

## Run Tests
```bash
python -m unittest discover -s tests -p "test_*.py"
```
