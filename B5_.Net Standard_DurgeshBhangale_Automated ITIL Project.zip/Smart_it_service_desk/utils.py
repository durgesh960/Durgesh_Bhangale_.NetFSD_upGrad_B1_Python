import csv
import json
import os

from logger import get_logger


DATA_FILE = "data/tickets.json"
LOG_FILE = "data/logs.txt"
BACKUP_FILE = "data/backup.csv"
PROBLEM_FILE = "data/problems.json"


def _ensure_data_files():
    os.makedirs("data", exist_ok=True)
    for path, default in ((DATA_FILE, []), (PROBLEM_FILE, [])):
        if not os.path.exists(path):
            with open(path, "w", encoding="utf-8") as handle:
                json.dump(default, handle)
    if not os.path.exists(LOG_FILE):
        with open(LOG_FILE, "a", encoding="utf-8"):
            pass
    if not os.path.exists(BACKUP_FILE):
        with open(BACKUP_FILE, "a", encoding="utf-8"):
            pass


def load_tickets():
    _ensure_data_files()
    logger = get_logger()
    try:
        with open(DATA_FILE, "r", encoding="utf-8") as handle:
            data = json.load(handle)
            return data if isinstance(data, list) else []
    except FileNotFoundError:
        logger.error("Ticket storage file not found: %s", DATA_FILE)
        return []
    except json.JSONDecodeError:
        logger.error("Ticket storage is not valid JSON: %s", DATA_FILE)
        return []


def save_tickets(tickets):
    _ensure_data_files()
    with open(DATA_FILE, "w", encoding="utf-8") as handle:
        json.dump(tickets, handle, indent=4)
    backup_tickets(tickets)


def log_event(event, level="info"):
    logger = get_logger()
    level_value = level.lower()
    if level_value == "warning":
        logger.warning(event)
    elif level_value == "error":
        logger.error(event)
    elif level_value == "critical":
        logger.critical(event)
    else:
        logger.info(event)


def backup_tickets(tickets):
    _ensure_data_files()
    if not tickets:
        with open(BACKUP_FILE, "w", encoding="utf-8", newline=""):
            pass
        return

    with open(BACKUP_FILE, "w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=tickets[0].keys())
        writer.writeheader()
        writer.writerows(tickets)
