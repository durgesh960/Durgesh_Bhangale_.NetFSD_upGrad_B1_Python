import datetime
import json
import os
import re
from functools import reduce

from logger import get_logger
from tickets import IncidentTicket, ProblemRecord, ServiceRequest, Ticket


PROBLEM_FILE = "data/problems.json"
CHANGE_FILE = "data/changes.json"


class ITILException(Exception):
    pass


class InvalidTicketIDError(ITILException):
    pass


class DuplicateRecordError(ITILException):
    pass


class EmptyValueError(ITILException):
    pass


def audit_action(action_name):
    def decorator(func):
        def wrapper(*args, **kwargs):
            logger = get_logger()
            logger.info("ACTION START: %s", action_name)
            try:
                result = func(*args, **kwargs)
                logger.info("ACTION SUCCESS: %s", action_name)
                return result
            except Exception:
                logger.error("ACTION FAILURE: %s", action_name, exc_info=True)
                raise
        return wrapper
    return decorator


def _parse_datetime(value):
    if not value:
        return None
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M"):
        try:
            return datetime.datetime.strptime(value, fmt)
        except ValueError:
            continue
    return None


class ITILManager:
    def __init__(self):
        self.logger = get_logger()

    @staticmethod
    def classify_ticket(employee, dept, issue, category):
        request_pattern = re.compile(r"password reset|software install|access request", re.IGNORECASE)
        if request_pattern.search(issue) or category.lower() == "service":
            return ServiceRequest(employee, dept, issue, category)
        return IncidentTicket(employee, dept, issue, category)

    @audit_action("create_ticket")
    def create_ticket(self, tickets, employee, dept, issue, category):
        if not all([employee.strip(), dept.strip(), issue.strip(), category.strip()]):
            raise EmptyValueError("Employee, department, issue and category are mandatory")

        duplicate = next(
            (
                record
                for record in tickets
                if record.get("employee", "").lower() == employee.lower()
                and record.get("dept", "").lower() == dept.lower()
                and record.get("issue", "").lower() == issue.lower()
                and record.get("status") != "Closed"
            ),
            None,
        )
        if duplicate:
            raise DuplicateRecordError("Similar open ticket already exists")

        ticket = self.classify_ticket(employee, dept, issue, category)
        tickets.append(ticket.to_dict())
        self.logger.info("Ticket created | id=%s", ticket.id)
        return ticket.to_dict()

    @staticmethod
    def search_ticket_by_id(tickets, ticket_id):
        ticket = next((record for record in tickets if record.get("id") == ticket_id), None)
        if not ticket:
            raise InvalidTicketIDError(f"Ticket not found: {ticket_id}")
        return ticket

    @audit_action("update_ticket_status")
    def update_ticket_status(self, tickets, ticket_id, status):
        ticket = self.search_ticket_by_id(tickets, ticket_id)
        if status not in Ticket.VALID_STATUS:
            raise ValueError(f"Unsupported status: {status}")
        ticket["status"] = status
        self.logger.info("Ticket updated | id=%s status=%s", ticket_id, status)
        return ticket

    @audit_action("close_ticket")
    def close_ticket(self, tickets, ticket_id):
        ticket = self.search_ticket_by_id(tickets, ticket_id)
        ticket["status"] = "Closed"
        ticket["closed"] = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        self.logger.info("Ticket closed | id=%s", ticket_id)
        return ticket

    @audit_action("delete_ticket")
    def delete_ticket(self, tickets, ticket_id):
        self.search_ticket_by_id(tickets, ticket_id)
        filtered = [record for record in tickets if record.get("id") != ticket_id]
        self.logger.warning("Ticket deleted | id=%s", ticket_id)
        return filtered

    @staticmethod
    def pending_tickets(tickets):
        for record in tickets:
            if record.get("status") not in {"Closed", "SLA Breached"}:
                yield record

    def breached_sla_tickets(self, tickets):
        now = datetime.datetime.now()
        breached = []
        for record in self.pending_tickets(tickets):
            created = _parse_datetime(record.get("created"))
            if not created:
                continue
            allowed_hours = Ticket.sla_for_priority(record.get("priority", "P4"))
            if now > created + datetime.timedelta(hours=allowed_hours):
                record["status"] = "SLA Breached"
                breached.append(record)
                self.logger.warning("SLA breach | id=%s", record.get("id"))
        return breached

    def escalate_unresolved(self, tickets):
        now = datetime.datetime.now()
        escalated = []
        for record in self.pending_tickets(tickets):
            created = _parse_datetime(record.get("created"))
            if not created:
                continue
            allowed_hours = Ticket.sla_for_priority(record.get("priority", "P4"))
            threshold = created + datetime.timedelta(hours=max(1, allowed_hours // 2))
            if now >= threshold and record.get("status") == "Open":
                record["status"] = "Escalated"
                escalated.append(record)
                self.logger.critical("Escalation triggered | id=%s", record.get("id"))
        return escalated

    @staticmethod
    def sort_tickets(tickets, key="created"):
        return sorted(tickets, key=lambda row: row.get(key, ""))

    def create_problem_records(self, tickets):
        issue_counts = {}
        for issue in map(lambda item: item.get("issue", "Unknown"), tickets):
            issue_counts[issue] = issue_counts.get(issue, 0) + 1

        repeated = list(filter(lambda item: item[1] >= 5, issue_counts.items()))
        if not repeated:
            return []

        os.makedirs("data", exist_ok=True)
        existing = []
        if os.path.exists(PROBLEM_FILE):
            with open(PROBLEM_FILE, "r", encoding="utf-8") as handle:
                try:
                    existing = json.load(handle)
                except json.JSONDecodeError:
                    existing = []

        existing_issues = {record.get("issue") for record in existing}
        new_records = []
        for issue, occurrences in repeated:
            if issue in existing_issues:
                continue
            problem = ProblemRecord(
                employee="System",
                dept="IT",
                issue=issue,
                category="Problem",
                status="Open",
                occurrences=occurrences,
            )
            new_records.append(problem.to_dict())

        if new_records:
            combined = existing + new_records
            with open(PROBLEM_FILE, "w", encoding="utf-8") as handle:
                json.dump(combined, handle, indent=4)
            self.logger.warning("Problem records generated | count=%s", len(new_records))

        return new_records

    def average_resolution_hours(self, tickets):
        closed_tickets = [row for row in tickets if row.get("status") == "Closed" and row.get("closed")]
        if not closed_tickets:
            return 0.0

        durations = []
        for row in closed_tickets:
            created = _parse_datetime(row.get("created"))
            closed = _parse_datetime(row.get("closed"))
            if created and closed:
                durations.append((closed - created).total_seconds() / 3600)

        if not durations:
            return 0.0
        total = reduce(lambda left, right: left + right, durations)
        return round(total / len(durations), 2)

    def track_change(self, change_title, requested_by):
        if not change_title.strip() or not requested_by.strip():
            raise EmptyValueError("Change title and requested_by are required")

        os.makedirs("data", exist_ok=True)
        records = []
        if os.path.exists(CHANGE_FILE):
            with open(CHANGE_FILE, "r", encoding="utf-8") as handle:
                try:
                    records = json.load(handle)
                except json.JSONDecodeError:
                    records = []

        payload = {
            "id": Ticket.generate_id(),
            "change_title": change_title,
            "requested_by": requested_by,
            "created": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "status": "Requested",
        }
        records.append(payload)
        with open(CHANGE_FILE, "w", encoding="utf-8") as handle:
            json.dump(records, handle, indent=4)
        self.logger.info("Change request tracked | id=%s", payload["id"])
        return payload
