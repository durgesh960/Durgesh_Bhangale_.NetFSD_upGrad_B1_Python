import datetime
import json
import logging
import os
import tempfile
import unittest
from unittest.mock import patch

from itil import EmptyValueError, ITILManager, InvalidTicketIDError
from monitor import Monitor
from tickets import Ticket
from utils import load_tickets, save_tickets


class SmartITServiceDeskTests(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.data_dir = os.path.join(self.temp_dir.name, "data")
        os.makedirs(self.data_dir, exist_ok=True)

        self.ticket_file = os.path.join(self.data_dir, "tickets.json")
        self.backup_file = os.path.join(self.data_dir, "backup.csv")
        self.log_file = os.path.join(self.data_dir, "logs.txt")
        self.problem_file = os.path.join(self.data_dir, "problems.json")
        self.change_file = os.path.join(self.data_dir, "changes.json")

        for path, default in (
            (self.ticket_file, []),
            (self.problem_file, []),
            (self.change_file, []),
        ):
            with open(path, "w", encoding="utf-8") as handle:
                json.dump(default, handle)

        self.patches = [
            patch("utils.DATA_FILE", self.ticket_file),
            patch("utils.BACKUP_FILE", self.backup_file),
            patch("utils.LOG_FILE", self.log_file),
            patch("utils.PROBLEM_FILE", self.problem_file),
            patch("logger.LOG_FILE", self.log_file),
            patch("itil.PROBLEM_FILE", self.problem_file),
            patch("itil.CHANGE_FILE", self.change_file),
        ]
        for patcher in self.patches:
            patcher.start()

    def tearDown(self):
        for patcher in reversed(self.patches):
            patcher.stop()

        logger = logging.getLogger("smart_it_service_desk")
        for handler in list(logger.handlers):
            handler.close()
            logger.removeHandler(handler)

        self.temp_dir.cleanup()

    def test_ticket_creation(self):
        manager = ITILManager()
        tickets = []
        created = manager.create_ticket(tickets, "Asha", "Finance", "Internet Down", "Incident")
        self.assertEqual(created["employee"], "Asha")
        self.assertEqual(len(tickets), 1)

    def test_priority_logic(self):
        self.assertEqual(Ticket.assign_priority("Server Down"), "P1")
        self.assertEqual(Ticket.assign_priority("Internet Down"), "P2")
        self.assertEqual(Ticket.assign_priority("Laptop Slow"), "P3")
        self.assertEqual(Ticket.assign_priority("Password Reset"), "P4")

    def test_sla_breach(self):
        manager = ITILManager()
        old_time = (datetime.datetime.now() - datetime.timedelta(hours=3)).strftime("%Y-%m-%d %H:%M:%S")
        tickets = [
            {
                "id": "x1",
                "employee": "Emp",
                "dept": "IT",
                "issue": "Server Down",
                "category": "Incident",
                "priority": "P1",
                "status": "Open",
                "created": old_time,
                "closed": None,
            }
        ]
        breached = manager.breached_sla_tickets(tickets)
        self.assertEqual(len(breached), 1)
        self.assertEqual(tickets[0]["status"], "SLA Breached")

    def test_auto_monitoring_ticket_creation(self):
        monitor = Monitor(cpu_threshold=90, ram_threshold=95, disk_free_threshold=10)
        monitor.get_metrics = lambda: {"cpu": 99, "memory": 96, "disk_free": 5, "network_mbps": 10}

        payload = monitor.monitor_system()
        self.assertIsNotNone(payload)
        self.assertEqual(payload["priority"], "P1")

    def test_file_read_write(self):
        records = [
            {
                "id": "abc123",
                "employee": "Ravi",
                "dept": "HR",
                "issue": "Password Reset",
                "category": "Service",
                "priority": "P4",
                "status": "Open",
                "created": "2026-04-29 10:00:00",
                "closed": None,
            }
        ]
        save_tickets(records)
        loaded = load_tickets()
        self.assertEqual(len(loaded), 1)
        self.assertEqual(loaded[0]["id"], "abc123")

    def test_search_ticket(self):
        manager = ITILManager()
        tickets = [{"id": "t001", "status": "Open"}]
        record = manager.search_ticket_by_id(tickets, "t001")
        self.assertEqual(record["id"], "t001")

    def test_exception_handling(self):
        manager = ITILManager()
        with self.assertRaises(EmptyValueError):
            manager.create_ticket([], "", "IT", "Server Down", "Incident")
        with self.assertRaises(InvalidTicketIDError):
            manager.search_ticket_by_id([], "invalid")


if __name__ == "__main__":
    unittest.main()
