import psutil

from itil import ITILManager
from tickets import IncidentTicket
from utils import load_tickets, log_event, save_tickets


class Monitor:
    def __init__(self, cpu_threshold=90, ram_threshold=95, disk_free_threshold=10, network_mbps_threshold=500):
        self.cpu_threshold = cpu_threshold
        self.ram_threshold = ram_threshold
        self.disk_free_threshold = disk_free_threshold
        self.network_mbps_threshold = network_mbps_threshold
        self._last_network_total = None
        self.itil_manager = ITILManager()

    def get_metrics(self):
        cpu = psutil.cpu_percent(interval=1)
        memory = psutil.virtual_memory().percent
        disk_info = psutil.disk_usage("/")
        disk_free_percent = 100 - disk_info.percent

        counters = psutil.net_io_counters()
        current_total = counters.bytes_recv + counters.bytes_sent
        if self._last_network_total is None:
            network_mbps = 0.0
        else:
            delta_bytes = max(0, current_total - self._last_network_total)
            network_mbps = round((delta_bytes * 8) / 1_000_000, 2)
        self._last_network_total = current_total

        return {
            "cpu": cpu,
            "memory": memory,
            "disk_free": round(disk_free_percent, 2),
            "network_mbps": network_mbps,
        }

    def _breach_reasons(self, metrics):
        reasons = []
        if metrics["cpu"] > self.cpu_threshold:
            reasons.append(f"CPU>{self.cpu_threshold}%")
        if metrics["memory"] > self.ram_threshold:
            reasons.append(f"RAM>{self.ram_threshold}%")
        if metrics["disk_free"] < self.disk_free_threshold:
            reasons.append(f"DiskFree<{self.disk_free_threshold}%")
        if metrics["network_mbps"] > self.network_mbps_threshold:
            reasons.append(f"Network>{self.network_mbps_threshold}Mbps")
        return reasons

    def monitor_system(self):
        metrics = self.get_metrics()
        reasons = self._breach_reasons(metrics)
        print("System Metrics:", metrics)

        if not reasons:
            log_event("Monitoring cycle completed with no threshold breach", "info")
            return None

        tickets = load_tickets()
        incident = IncidentTicket(
            employee="System",
            dept="IT",
            issue="Monitoring Threshold Breach",
            category="Monitoring",
            priority="P1",
        )
        payload = incident.to_dict()
        payload["breach_reasons"] = reasons
        tickets.append(payload)

        # Apply ITIL workflows after auto-creation.
        self.itil_manager.breached_sla_tickets(tickets)
        self.itil_manager.escalate_unresolved(tickets)
        self.itil_manager.create_problem_records(tickets)

        save_tickets(tickets)
        log_event(f"Monitoring alert ticket raised | reasons={','.join(reasons)}", "critical")
        print("Auto Ticket Raised:", payload)
        return payload


def monitor_system():
    monitor = Monitor()
    return monitor.monitor_system()
