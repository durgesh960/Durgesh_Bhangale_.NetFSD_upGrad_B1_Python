# DurgeshLearn - Multi-Page E-Learning Platform

A comprehensive e-learning platform featuring structured courses, interactive quizzes, and progress tracking. Built with modern web technologies for an engaging learning experience.

## 🚀 Features

### Core Functionality
- **Multi-Page Navigation**: Dashboard, Courses, Quiz, and Profile pages
- **Course Management**: Browse, enroll, and track progress on various courses
- **Interactive Quizz**: Dynamic quiz system with grading and feedback
- **Progress Tracking**: Visual progress bars and completion statistics
- **Data Persistence**: Local storage for user progress and quiz history

### Courses Available
- JavaScript Basics (Variables, functions, DOM manipulation)
- Power BI Fundamentals (Data modeling and visualization)

### Quiz System
- 10-question multiple choice quiz
- Automatic grading (A-F scale)
- Pass/fail determination (50% threshold)
- Score history tracking
- Detailed feedback based on performance

## 🛠️ Technologies Used

- **Frontend**: HTML5, CSS3, JavaScript
- **Styling**: Custom CSS with animations and gradients
- **Data Storage**: Browser localStorage API
- **Testing**: Jest framework
- **Architecture**: Modular JavaScript

## 📁 Project Structure

```
├── Dashboard.html          # Main dashboard page
├── Courses.html           # Course listing page
├── Quiz.html             # Quiz interface
├── Profile.html          # User profile and progress
├── quiz.js               # Quiz logic and questions
├── package.json          # Project dependencies and scripts
├── css/
│   └── style.css         # Main stylesheet
└── js/
    ├── storage.js        # Data persistence and UI logic
    └── quiz.test.js      # Unit tests for quiz functions
```

## 🏃‍♂️ Getting Started

### Prerequisites
- Modern web browser (Chrome, Firefox, Safari, Edge)
- Node.js (for running tests)

### Installation

1. **Clone or download** the project files to your local machine

2. **Open in browser**: Simply open `Dashboard.html` in your web browser to start using the platform

### Running Tests

```bash
# Install dependencies
npm install

# Run tests
npm test
```

## 📖 Usage

### Navigation
- Use the navigation bar to switch between Dashboard, Courses, Quiz, and Profile pages
- Search for courses using the search bar in the header

### Course Enrollment
1. Browse available courses on the Dashboard or Courses page
2. Click "Enroll Now" to enroll in a course
3. Click "Start Course" to begin learning
4. Complete courses to mark them as finished

### Taking Quizzes
1. Navigate to the Quiz page
2. Answer all questions by selecting radio button options
3. Click "Submit Quiz" to see your results
4. View your score, grade, and feedback

### Progress Tracking
- View completion progress on the Dashboard
- Check enrolled and completed courses
- Review quiz history on the Profile page

## 🎨 Design Features

- **Animated Background**: Dynamic gradient background with floating elements
- **Responsive Design**: Works on desktop and mobile devices
- **Hover Effects**: Interactive course cards with animations
- **Progress Visualization**: Progress bars for course completion
- **Toast Notifications**: Success messages for course completion

## 🧪 Testing

The project includes unit tests for core quiz functionality:
- Percentage calculation
- Grade assignment
- Pass/fail logic

Run tests with `npm test` to ensure functionality works correctly.

## 📊 Data Storage

User data is stored locally in the browser using localStorage:
- `durgeshLearn.completedCourses`: Array of completed course names
- `durgeshLearn.enrolledCourses`: Array of enrolled course names
- `durgeshLearn.quizHistory`: Array of quiz attempt objects


## 📝 License

This project is created for educational purposes.

## 👨‍💻 Author

**Durgesh Vijay Bhangale**
- Created as part of Cognizant training mini project
- Built in 2026

---
