function calculateGrade(percent) {
  if (percent >= 90) {
    return "A";
  } else if (percent >= 80) {
    return "B";
  } else if (percent >= 70) {
    return "C";
  } else if (percent >= 60) {
    return "D";
  } else {
    return "F";
  }
}

function calculatePercentage(score, total) {
  return (score / total) * 100;
}

function isPass(percent) {
  return percent >= 50;
}

const questions = [
  { q: "HTML stands for?", options: ["Hyper Text Markup Language", "High Tech Modern Language", "Home Tool Markup Language", "Hyperlink and Text Markup Language"], answer: 0 },
  { q: "CSS is used for?", options: ["Styling web pages", "Creating databases", "Server-side scripting", "Handling user input"], answer: 0 },
  { q: "Power BI is a tool for?", options: ["Data Visualization", "Web Hosting", "Code Editing", "Version Control"], answer: 0 },
  { q: "What does SQL stand for?", options: ["Structured Query Language", "Simple Query Language", "System Query Language", "Standard Query Language"], answer: 0 },
  { q: "Which language is primarily used for web development?", options: ["JavaScript", "Python", "C++", "Java"], answer: 0 },
  { q: "What is the purpose of a database?", options: ["Store and manage data", "Display graphics", "Compile code", "Run servers"], answer: 0 },
  { q: "Azure is a?", options: ["Cloud computing platform", "Programming language", "Database system", "Web browser"], answer: 0 },
  { q: "What does API stand for?", options: ["Application Programming Interface", "Advanced Programming Interface", "Automated Program Interface", "Application Process Interface"], answer: 0 },
  { q: "Which of these is a version control system?", options: ["Git", "HTML", "CSS", "JavaScript"], answer: 0 },
  { q: "What is machine learning?", options: ["A type of AI that learns from data", "A programming language", "A database tool", "A web framework"], answer: 0 }
];

async function loadQuiz() {
  return new Promise(resolve => {
    setTimeout(() => resolve(questions), 1000);
  });
}

async function renderQuiz() {
  const quizData = await loadQuiz();
  const container = document.getElementById("quiz-container");
  const progress = document.createElement("progress");
  progress.id = "quizProgress";
  progress.max = quizData.length;
  progress.value = 0;
  container.appendChild(progress);
  quizData.forEach((item, idx) => {
    const div = document.createElement("div");
    div.className = "question";
    div.innerHTML = `<p>${idx + 1}. ${item.q}</p>` +
      item.options.map((opt, i) =>
        `<label><input type="radio" name="q${idx}" value="${i}" onchange="updateProgress()">${opt}</label>`).join("<br>");
    container.appendChild(div);
  });
}

function updateProgress() {
  const totalQuestions = questions.length;
  let answered = 0;
  questions.forEach((_, idx) => {
    if (document.querySelector(`input[name="q${idx}"]:checked`)) answered++;
  });
  const progress = document.getElementById("quizProgress");
  progress.value = answered;
}

document.getElementById("submitQuiz").onclick = () => {
  let score = 0;
  questions.forEach((q, idx) => {
    const selected = document.querySelector(`input[name="q${idx}"]:checked`);
    if (selected && parseInt(selected.value) === q.answer) score++;
  });
  const percent = calculatePercentage(score, questions.length);
  const grade = calculateGrade(percent);
  const pass = isPass(percent);
  let feedback;
  switch(true){
    case percent >= 80: feedback = "Excellent work!"; break;
    case percent >= 50: feedback = "Good job, keep practicing."; break;
    default: feedback = "Needs improvement, try again.";
  }
  localStorage.setItem("quizScore", score);
  localStorage.setItem("quizGrade", grade);
  if (window.DurgeshLearn?.addQuizScore) {
    DurgeshLearn.addQuizScore({
      score,
      total: questions.length,
      percent,
      grade,
      date: new Date().toLocaleString(),
    });
    window.DurgeshLearn?.updateProfileSummary?.();
  }

  document.getElementById("result").innerText = `Score: ${score}/${questions.length} (${percent.toFixed(2)}%) - Grade: ${grade} - ${feedback}`;
};

renderQuiz();