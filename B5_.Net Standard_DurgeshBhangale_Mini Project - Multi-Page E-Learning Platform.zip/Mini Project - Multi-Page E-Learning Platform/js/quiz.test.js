const { calculateGrade, calculatePercentage, isPass } = require('./quiz.js');

describe('Quiz Logic Tests', () => {
  test('calculatePercentage should return correct percentage', () => {
    expect(calculatePercentage(5, 10)).toBe(50);
    expect(calculatePercentage(8, 10)).toBe(80);
    expect(calculatePercentage(0, 10)).toBe(0);
  });

  test('calculateGrade should return correct grade', () => {
    expect(calculateGrade(95)).toBe('A');
    expect(calculateGrade(85)).toBe('B');
    expect(calculateGrade(75)).toBe('C');
    expect(calculateGrade(65)).toBe('D');
    expect(calculateGrade(45)).toBe('F');
  });

  test('isPass should determine pass/fail correctly', () => {
    expect(isPass(50)).toBe(true);
    expect(isPass(49)).toBe(false);
    expect(isPass(100)).toBe(true);
    expect(isPass(0)).toBe(false);
  });
});