

const DurgeshLearn = (() => {
  const KEYS = {
    completed: "durgeshLearn.completedCourses",
    enrolled: "durgeshLearn.enrolledCourses",
    quizHistory: "durgeshLearn.quizHistory",
  };

  const read = (key, fallback) => {
    try {
      const raw = localStorage.getItem(key);
      return raw ? JSON.parse(raw) : fallback;
    } catch (err) {
      console.warn(`Failed to read ${key} from localStorage`, err);
      return fallback;
    }
  };

  const write = (key, value) => {
    try {
      localStorage.setItem(key, JSON.stringify(value));
    } catch (err) {
      console.warn(`Failed to write ${key} to localStorage`, err);
    }
  };

  const getCompletedCourses = () => read(KEYS.completed, []);
  const getEnrolledCourses = () => read(KEYS.enrolled, []);
  const getQuizHistory = () => read(KEYS.quizHistory, []);

  const addItem = (key, value) => {
    const list = read(key, []);
    if (!list.includes(value)) {
      list.push(value);
      write(key, list);
    }
    return list;
  };

  const addCompletedCourse = (course) => addItem(KEYS.completed, course);
  const addEnrolledCourse = (course) => addItem(KEYS.enrolled, course);
  const addQuizScore = (scoreObj) => {
    const history = getQuizHistory();
    history.unshift(scoreObj);

    write(KEYS.quizHistory, history.slice(0, 10));
  };

  const markCompleted = (course) => {
    addCompletedCourse(course);
    updateCourseButtons();
    updateProfileSummary();
    const toast = document.createElement("div");
    toast.textContent = `Nice! You completed “${course}”.`;
    toast.className = "toast";
    document.body.appendChild(toast);
    window.setTimeout(() => toast.classList.add("visible"), 30);
    window.setTimeout(() => toast.classList.remove("visible"), 2600);
    window.setTimeout(() => toast.remove(), 3000);
  };

  const updateCourseButtons = () => {
    document.querySelectorAll(".course-card").forEach(card => {
      const title = card.querySelector("h3")?.innerText?.trim();
      const button = card.querySelector("button");
      if (!title || !button) return;

      const completed = getCompletedCourses().includes(title);
      const enrolled = getEnrolledCourses().includes(title);

      if (completed) {
        button.textContent = "Completed";
        button.disabled = true;
        button.classList.add("disabled");
      } else if (enrolled) {
        button.textContent = "Start Course";
        button.disabled = false;
      } else {
        button.textContent = "Enroll Now";
        button.disabled = false;
      }

      const progress = card.querySelector(".course-progress");
      if (progress) {
        const percent = completed ? 100 : enrolled ? 50 : 0;
        progress.value = percent;
        progress.title = `${percent}% complete`;
      }
    });
  };

  const initCourseActions = () => {
    document.querySelectorAll(".course-card button").forEach(btn => {
      btn.addEventListener("click", (event) => {
        const card = event.target.closest(".course-card");
        const title = card?.querySelector("h3")?.innerText?.trim();
        if (!title) return;

        if (getCompletedCourses().includes(title)) return;

        if (btn.textContent.toLowerCase().includes("enroll")) {
          addEnrolledCourse(title);
          btn.textContent = "Start Course";
          btn.classList.add("enrolled");
          return;
        }

        // If not enrolled, treat click as enroll
        if (btn.textContent.toLowerCase().includes("start")) {
          markCompleted(title);
          return;
        }

        // For manual 'Mark Completed' buttons
        if (btn.getAttribute("data-mark-completed") === "true") {
          markCompleted(title);
        }
      });
    });

    updateCourseButtons();
  };

  const initSearch = () => {
    const searchInput = document.getElementById("searchInput");
    const cards = Array.from(document.querySelectorAll(".course-card"));
    if (!searchInput || !cards.length) return;

    const filter = () => {
      const term = searchInput.value.trim().toLowerCase();
      cards.forEach(card => {
        const title = card.querySelector("h3")?.innerText?.toLowerCase() || "";
        const desc = card.querySelector("p")?.innerText?.toLowerCase() || "";
        const match = !term || title.includes(term) || desc.includes(term);
        card.style.display = match ? "grid" : "none";
      });
    };

    searchInput.addEventListener("input", filter);
    filter();
  };

  const updateProfileSummary = () => {
    const completed = getCompletedCourses();
    const enrolled = getEnrolledCourses();
    const quizHistory = getQuizHistory();

    const completedEl = document.getElementById("completed");
    const enrolledEl = document.getElementById("enrolled");
    const quizHistoryEl = document.getElementById("quizHistory");
    const progressEl = document.getElementById("completionProgress");

    if (completedEl) {
      completedEl.innerText = completed.length ? completed.join(" • ") : "None yet";
    }
    if (enrolledEl) {
      enrolledEl.innerText = enrolled.length ? enrolled.join(" • ") : "No courses enrolled";
    }
    if (quizHistoryEl) {
      quizHistoryEl.innerHTML = quizHistory.length
        ? quizHistory.slice(0, 3).map(item => `<li>${item.date} — ${item.score}/${item.total} (${item.percent}%)</li>`).join("")
        : "<li>No quiz attempts yet.</li>";
    }
    if (progressEl) {
      const total = Math.max(enrolled.length, completed.length, 1);
      const percent = Math.min(100, Math.round((completed.length / total) * 100));
      progressEl.value = percent;
    }
  };

  const initBackground = () => {

    document.body.classList.add("has-background-effect");
  };

  const init = () => {
    initBackground();
    updateCourseButtons();
    initCourseActions();
    initSearch();
    updateProfileSummary();
  };

  return {
    init,
    markCompleted,
    addQuizScore,
    updateProfileSummary,
  };
})();

window.DurgeshLearn = DurgeshLearn;

window.addEventListener("DOMContentLoaded", () => {
  DurgeshLearn.init();

  window.markCompleted = DurgeshLearn.markCompleted;
});
