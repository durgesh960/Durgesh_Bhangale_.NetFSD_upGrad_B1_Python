import json, csv, os, datetime

DATA_FILE = "data/tickets.json"
LOG_FILE = "data/logs.txt"
BACKUP_FILE = "data/backup.csv"

def load_tickets():
    if os.path.exists(DATA_FILE):
        with open(DATA_FILE) as f: return json.load(f)
    return []

def save_tickets(tickets):
    with open(DATA_FILE,"w") as f: json.dump(tickets,f,indent=4)
    backup_tickets(tickets)

def log_event(event):
    with open(LOG_FILE,"a") as f:
        f.write(f"{datetime.datetime.now()} - {event}\n")

def backup_tickets(tickets):
    with open(BACKUP_FILE,"w",newline="") as f:
        writer=csv.DictWriter(f,fieldnames=tickets[0].keys() if tickets else [])
        if tickets: writer.writeheader(); writer.writerows(tickets)
