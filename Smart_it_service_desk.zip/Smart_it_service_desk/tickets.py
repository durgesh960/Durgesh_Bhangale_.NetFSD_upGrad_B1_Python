import datetime, uuid

class Ticket:
    def __init__(self, employee, dept, issue, category):
        self.id = str(uuid.uuid4())[:8]
        self.employee = employee
        self.dept = dept
        self.issue = issue
        self.category = category
        self.priority = self.assign_priority(issue)
        self.status = "Open"
        self.created = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")

    def assign_priority(self, issue):
        mapping = {
            "Server Down": "P1",
            "Internet Down": "P2",
            "Laptop Slow": "P3",
            "Password Reset": "P4"
        }
        return mapping.get(issue, "P4")

class IncidentTicket(Ticket): pass
class ServiceRequest(Ticket): pass
class ProblemRecord(Ticket): pass
