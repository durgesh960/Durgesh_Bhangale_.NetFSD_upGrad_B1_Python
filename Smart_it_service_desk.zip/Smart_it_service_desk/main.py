from tickets import Ticket
from utils import load_tickets, save_tickets, log_event
from monitor import monitor_system
from reports import daily_summary, monthly_trend

def menu():
    while True:
        print("\nSmart IT Service Desk")
        print("1. Create Ticket")
        print("2. View All Tickets")
        print("3. Search Ticket by ID")
        print("4. Update Ticket Status")
        print("5. Close Ticket")
        print("6. Delete Ticket")
        print("7. Monitor System")
        print("8. Daily Report")
        print("9. Monthly Report")
        print("10. Exit")

        choice = input("Choose option: ")
        tickets = load_tickets()

        try:
            if choice=="1":
                emp=input("Employee: "); dept=input("Dept: "); issue=input("Issue: "); cat=input("Category: ")
                if not issue: raise ValueError("Empty issue description")
                t=Ticket(emp,dept,issue,cat)
                tickets.append(t.__dict__); save_tickets(tickets); log_event("Ticket created"); print("✅ Ticket Created:",t.__dict__)
            elif choice=="2": [print(t) for t in tickets]
            elif choice=="3":
                tid=input("Enter ID: ")
                print(next((t for t in tickets if t['id']==tid),"Not found"))
            elif choice=="4":
                tid=input("Enter ID: ")
                for t in tickets:
                    if t['id']==tid: t['status']="In Progress"; save_tickets(tickets); log_event("Ticket updated")
            elif choice=="5":
                tid=input("Enter ID: ")
                for t in tickets:
                    if t['id']==tid: t['status']="Closed"; save_tickets(tickets); log_event("Ticket closed")
            elif choice=="6":
                tid=input("Enter ID: ")
                tickets=[t for t in tickets if t['id']!=tid]; save_tickets(tickets); log_event("Ticket deleted")
            elif choice=="7": monitor_system()
            elif choice=="8": daily_summary()
            elif choice=="9": monthly_trend()
            elif choice=="10": break
            else: print("Invalid input")
        except Exception as e:
            log_event(f"Error: {e}")
            print("❌ Error:",e)

if __name__=="__main__":
    menu()
