from utils import load_tickets
from collections import Counter
import datetime

def daily_summary():
    tickets = load_tickets()
    today = datetime.datetime.now().strftime("%Y-%m-%d")
    today_tickets = [t for t in tickets if t['created'].startswith(today)]
    print("Daily Summary Report")
    print("Total:", len(today_tickets))
    print("Open:", sum(1 for t in today_tickets if t['status']=="Open"))
    print("Closed:", sum(1 for t in today_tickets if t['status']=="Closed"))
    print("High Priority:", sum(1 for t in today_tickets if t['priority']=="P1"))
    print("SLA Breached:", sum(1 for t in today_tickets if t['status']=="SLA Breached"))

def monthly_trend():
    tickets = load_tickets()
    issues = [t['issue'] for t in tickets]
    dept = [t['dept'] for t in tickets]
    print("Monthly Trend Report")
    print("Most common issue:", Counter(issues).most_common(1))
    print("Department with most incidents:", Counter(dept).most_common(1))
