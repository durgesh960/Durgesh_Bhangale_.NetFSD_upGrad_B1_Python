import psutil
from tickets import Ticket
from utils import load_tickets, save_tickets, log_event

def monitor_system():
    cpu = psutil.cpu_percent()
    ram = psutil.virtual_memory().percent
    disk = psutil.disk_usage('/').percent

    if cpu > 90 or ram > 95 or disk > 90:
        tickets = load_tickets()
        t = Ticket("System","IT","High CPU/RAM/Disk","Monitoring")
        tickets.append(t.__dict__)
        save_tickets(tickets)
        log_event("Auto Ticket Raised due to system threshold breach")
        print("⚠️ Auto Ticket Raised:", t.__dict__)
