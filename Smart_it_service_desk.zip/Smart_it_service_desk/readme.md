# Smart IT Service Desk & System Monitoring Automation

## Features
- Ticket Management (Create, View, Search, Update, Close, Delete)
- Auto Priority Assignment
- SLA Tracking & Escalation
- System Monitoring (CPU, RAM, Disk)
- Auto Ticket Generation on Threshold Breach
- Logging & Backup
- Reports (Daily & Monthly)
- ITIL Practices (Incident, Service Request, Problem Management)

## Run
```bash
pip install psutil
python main.py
